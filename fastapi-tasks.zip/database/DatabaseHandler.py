import sqlite3


class DatabaseHandler:
    def __init__(self, db_name):
        self.conn = sqlite3.connect(db_name,check_same_thread=False)
        self.cursor = self.conn.cursor()
        self.create_tables()

    def create_tables(self):

        self.cursor.execute("""
                       CREATE TABLE IF NOT EXISTS users(
                       id INTEGER PRIMARY KEY AUTOINCREMENT,
                       user_name TEXT NOT NULL,
                       email TEXT NOT NULL UNIQUE,
                       password TEXT NOT NULL
                       )
                    """)
        self.cursor.execute("""
                       CREATE TABLE IF NOT EXISTS tasks(
                       id INTEGER PRIMARY KEY AUTOINCREMENT,
                       title TEXT NOT NULL,
                       description TEXT ,
                       status TEXT NOT NULL,
                       user_id INTEGER,
                       FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
                       )
                    """)
        self.conn.commit()

    def add_user(self,user):
        try:
            self.cursor.execute(
                "INSERT INTO users (user_name, email, password) VALUES (?, ?, ?)",
                (user.userName, user.Email, user.password)
            )
            self.conn.commit()
            return 1

        except sqlite3.IntegrityError:
            return 0

    def check_email(self,email,password):
        self.cursor.execute("SELECT * FROM users WHERE email = ? AND password=? ", (email,password))
        row = self.cursor.fetchone()  # fetch one record if found
        return row

    def get_user_by_email(self,email):
        self.cursor.execute("SELECT * FROM users WHERE email = ? ", (email, ))
        row = self.cursor.fetchone()  # fetch one record if found
        return row

    def delete_user(self,user_id):
        self.cursor.execute("DELETE FROM users WHERE id = ?", (user_id,))
        self.conn.commit()

    def get_all_users(self):
        self.cursor.execute("SELECT *  FROM users ")
        row = self.cursor.fetchall()  # fetch one record if found
        return row





    def insert_task(self ,user_id, task):
        self.cursor.execute(
            "INSERT INTO tasks (title, description, status,user_id) VALUES (?,?, ?, ?)",
            (task.title, task.description, task.status,user_id)
        )
        self.conn.commit()

    def get_tasks_by_user(self,user_id):
        self.cursor.execute("SELECT * FROM tasks WHERE user_id = ?", (user_id,))
        row = self.cursor.fetchall()
        return row

    def update_task_details(self,task_id, title, description,user_id):
        self.cursor.execute(
            "UPDATE tasks SET title = ?, description = ? WHERE id = ? AND user_id=?",
            (title, description, task_id,user_id)
        )
        self.conn.commit()
        if self.cursor.rowcount == 0:
            return 0
        else:
            return 1

    def update_task_status(self,task_id, status,user_id):
        self.cursor.execute(
            "UPDATE tasks SET status = ? WHERE id = ? AND user_id=?",
            (status, task_id,user_id)
        )
        self.conn.commit()
        if self.cursor.rowcount == 0:
            return 0
        else:
            return 1

    def delete_task(self,task_id,user_id):
        self.cursor.execute("DELETE FROM tasks WHERE id = ? AND user_id=?", (task_id,user_id))
        self.conn.commit()
        if self.cursor.rowcount == 0:
            return 0
        else:
            return 1

    def close_connection(self):
        self.conn.close()
